import { createRequire as __createRequire } from 'node:module'; const require = __createRequire(import.meta.url);

// apps/cowork-server/src/initDb.ts
import { join } from "node:path";

// packages/postgres-backend/src/database.ts
import postgres from "postgres";
function createPostgresDatabase(config) {
  return postgres({
    host: config.host,
    port: config.port,
    username: config.username,
    password: config.password,
    database: config.database,
    max: config.maxConnections ?? 10,
    idle_timeout: 20,
    connect_timeout: 10,
    prepare: false
  });
}
async function migratePostgres(sql) {
  await sql.begin(async (tx) => {
    await tx`SELECT pg_advisory_xact_lock(78234612001)`;
    await tx`
      CREATE TABLE IF NOT EXISTS app_users (
        id uuid PRIMARY KEY,
        sso_id text NOT NULL UNIQUE,
        username text NOT NULL,
        email text NOT NULL,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS user_model_credentials (
        user_id uuid PRIMARY KEY REFERENCES app_users(id) ON DELETE CASCADE,
        encrypted_token text NOT NULL,
        encryption_iv text NOT NULL,
        encryption_auth_tag text NOT NULL,
        encryption_key_version integer NOT NULL DEFAULT 1,
        token_fingerprint text NOT NULL,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS jobs (
        id text PRIMARY KEY,
        type text NOT NULL,
        payload jsonb NOT NULL,
        status text NOT NULL,
        priority integer NOT NULL DEFAULT 0,
        attempts integer NOT NULL DEFAULT 0,
        max_attempts integer NOT NULL DEFAULT 3,
        run_at bigint NOT NULL,
        locked_by text,
        locked_at bigint,
        lease_expires_at bigint,
        last_error text,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE INDEX IF NOT EXISTS idx_jobs_claim
      ON jobs(status, priority DESC, run_at, created_at)
    `;
    await tx`
      CREATE INDEX IF NOT EXISTS idx_jobs_lease
      ON jobs(status, lease_expires_at)
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS stored_blobs (
        id uuid PRIMARY KEY,
        owner_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
        lo_oid oid NOT NULL,
        file_name text NOT NULL,
        content_type text,
        size bigint NOT NULL,
        sha256 text NOT NULL,
        created_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS workflows (
        id text PRIMARY KEY,
        owner_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
        title text NOT NULL,
        schema_version integer NOT NULL,
        revision bigint NOT NULL,
        graph jsonb NOT NULL,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL
      )
    `;
    await tx`ALTER TABLE workflows ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES app_users(id) ON DELETE SET NULL`;
    await tx`CREATE INDEX IF NOT EXISTS workflows_owner_updated_idx ON workflows(owner_id, updated_at DESC)`;
    await tx`
      CREATE TABLE IF NOT EXISTS runs (
        id text PRIMARY KEY,
        user_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
        workflow_id text NOT NULL REFERENCES workflows(id) ON DELETE CASCADE,
        node_id text NOT NULL,
        status text NOT NULL,
        prompt text NOT NULL,
        kind text NOT NULL,
        input jsonb,
        provider_id text,
        provider_task_id text,
        provider_response_id text,
        result_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
        result jsonb,
        trace jsonb,
        error text,
        error_code text,
        error_retryable boolean,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL,
        started_at bigint NOT NULL,
        heartbeat_at bigint NOT NULL,
        finished_at bigint
      )
    `;
    await tx`
      CREATE INDEX IF NOT EXISTS idx_runs_workflow_updated
      ON runs(workflow_id, updated_at DESC)
    `;
    await tx`
      CREATE INDEX IF NOT EXISTS idx_runs_status ON runs(status)
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS node_run_events (
        id bigserial PRIMARY KEY,
        run_id text NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
        type text NOT NULL,
        data jsonb NOT NULL,
        created_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE INDEX IF NOT EXISTS idx_node_run_events_run
      ON node_run_events(run_id, id)
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS workflow_app_runs (
        id text PRIMARY KEY,
        workflow_id text NOT NULL REFERENCES workflows(id) ON DELETE CASCADE,
        revision bigint NOT NULL,
        status text NOT NULL,
        data jsonb NOT NULL,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE INDEX IF NOT EXISTS idx_workflow_app_runs_workflow
      ON workflow_app_runs(workflow_id, updated_at DESC)
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS resources (
        id uuid PRIMARY KEY,
        workspace_id text NOT NULL,
        kind text NOT NULL,
        name text NOT NULL,
        mime_type text,
        text_content text,
        blob_id uuid REFERENCES stored_blobs(id) ON DELETE SET NULL,
        url text,
        file_name text,
        metadata jsonb,
        source text NOT NULL,
        source_node_id text,
        source_run_id text,
        source_result_id text,
        provider_id text,
        model_id text,
        prompt text,
        generation_config jsonb,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL,
        deleted_at bigint
      )
    `;
    await tx`
      CREATE INDEX IF NOT EXISTS idx_resources_workspace
      ON resources(workspace_id, updated_at DESC)
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS resource_bindings (
        id uuid PRIMARY KEY,
        resource_id uuid NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
        workflow_id text NOT NULL REFERENCES workflows(id) ON DELETE CASCADE,
        node_id text,
        run_id text,
        result_id text,
        relation text NOT NULL,
        created_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE UNIQUE INDEX IF NOT EXISTS idx_resource_bindings_identity
      ON resource_bindings (
        resource_id,
        workflow_id,
        COALESCE(node_id, ''),
        COALESCE(run_id, ''),
        COALESCE(result_id, ''),
        relation
      )
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS chat_sessions (
        id text PRIMARY KEY,
        owner_id uuid REFERENCES app_users(id) ON DELETE CASCADE,
        title text NOT NULL,
        workflow_id text REFERENCES workflows(id) ON DELETE SET NULL,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS chat_messages (
        id text PRIMARY KEY,
        session_id text NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
        kind text NOT NULL,
        role text NOT NULL,
        text text NOT NULL,
        status text NOT NULL,
        agent_id text,
        agent_label text,
        model_id text,
        error text,
        run jsonb,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE INDEX IF NOT EXISTS idx_chat_messages_session
      ON chat_messages(session_id, created_at)
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS published_apps (
        id text PRIMARY KEY,
        owner_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
        title text NOT NULL,
        current_release_id text,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL
      )
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS app_releases (
        id text PRIMARY KEY,
        app_id text NOT NULL REFERENCES published_apps(id) ON DELETE CASCADE,
        version integer NOT NULL,
        html_content text NOT NULL,
        content_hash text NOT NULL,
        created_by uuid NOT NULL REFERENCES app_users(id) ON DELETE RESTRICT,
        created_at bigint NOT NULL,
        UNIQUE (app_id, version)
      )
    `;
    await tx`
      ALTER TABLE published_apps
      DROP CONSTRAINT IF EXISTS published_apps_current_release_id_fkey
    `;
    await tx`
      ALTER TABLE published_apps
      ADD CONSTRAINT published_apps_current_release_id_fkey
      FOREIGN KEY (current_release_id) REFERENCES app_releases(id) ON DELETE SET NULL
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS app_capabilities (
        id text PRIMARY KEY,
        app_id text NOT NULL REFERENCES published_apps(id) ON DELETE CASCADE,
        capability_key text NOT NULL,
        workflow_id text NOT NULL REFERENCES workflows(id) ON DELETE RESTRICT,
        workflow_revision bigint NOT NULL,
        subgraph_id text,
        created_at bigint NOT NULL,
        updated_at bigint NOT NULL,
        UNIQUE (app_id, capability_key)
      )
    `;
    await tx`
      ALTER TABLE app_capabilities
      ADD COLUMN IF NOT EXISTS subgraph_id text
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS runtime_sessions (
        id text PRIMARY KEY,
        token_hash text NOT NULL UNIQUE,
        user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
        app_id text NOT NULL REFERENCES published_apps(id) ON DELETE CASCADE,
        release_id text NOT NULL REFERENCES app_releases(id) ON DELETE CASCADE,
        expires_at bigint NOT NULL,
        created_at bigint NOT NULL,
        revoked_at bigint
      )
    `;
    await tx`
      CREATE INDEX IF NOT EXISTS idx_runtime_sessions_expiry
      ON runtime_sessions(expires_at)
    `;
    await tx`
      CREATE TABLE IF NOT EXISTS runtime_app_runs (
        run_id text PRIMARY KEY,
        session_id text NOT NULL REFERENCES runtime_sessions(id) ON DELETE CASCADE,
        app_id text NOT NULL REFERENCES published_apps(id) ON DELETE CASCADE,
        created_at bigint NOT NULL
      )
    `;
  });
}

// apps/cowork-server/src/config.ts
import { existsSync, readFileSync } from "node:fs";
var dbKeys = [
  "db.type",
  "db.host",
  "db.port",
  "db.username",
  "db.password",
  "db.database"
];
function readCoworkDatabase(path) {
  if (!existsSync(path)) throw new Error("db.properties is required in the application root");
  const properties = {};
  for (const source of readFileSync(path, "utf8").split(/\r?\n/)) {
    const line = source.trim();
    if (!line || line.startsWith("#")) continue;
    const separator = line.indexOf("=");
    if (separator < 0) throw new Error(`invalid db.properties line: ${line}`);
    properties[line.slice(0, separator).trim()] = line.slice(separator + 1).trim();
  }
  const unexpected = Object.keys(properties).filter(
    (key) => !dbKeys.includes(key)
  );
  if (unexpected.length) throw new Error(`unsupported db.properties keys: ${unexpected.join(", ")}`);
  const missing = dbKeys.filter((key) => !properties[key]);
  if (missing.length) throw new Error(`missing db.properties keys: ${missing.join(", ")}`);
  if (properties["db.type"] !== "postgresql") throw new Error("db.type must be postgresql");
  return {
    host: properties["db.host"],
    port: positiveInteger(properties["db.port"], 5432, "db.port"),
    username: properties["db.username"],
    password: properties["db.password"],
    database: properties["db.database"]
  };
}
function positiveInteger(value, fallback, name) {
  const parsed = value === void 0 ? fallback : Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) throw new Error(`${name} must be a positive integer`);
  return parsed;
}

// apps/cowork-server/src/initDb.ts
var database = createPostgresDatabase(
  readCoworkDatabase(join(process.cwd(), "db.properties"))
);
try {
  await migratePostgres(database);
  console.log("[init-db] PostgreSQL schema is ready");
} finally {
  await database.end({ timeout: 5 });
}
