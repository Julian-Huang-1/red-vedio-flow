#!/bin/sh
# health.sh - rendered from Cowork guard-transform template
curl -fsS -o /dev/null --max-time 3 "http://127.0.0.1:${APP_PORT:-3000}/health" || exit 1
