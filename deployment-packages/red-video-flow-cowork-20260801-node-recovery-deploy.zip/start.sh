#!/usr/bin/env bash
# start.sh - rendered from Cowork guard-transform Node template
set -eo pipefail
cd "$(dirname "$0")"

export APP_PORT="${APP_PORT:-3000}"
exec node server.js 2>&1
