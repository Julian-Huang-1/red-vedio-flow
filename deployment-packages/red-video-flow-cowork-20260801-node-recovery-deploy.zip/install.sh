#!/usr/bin/env bash
# install.sh - rendered from Cowork guard-transform Node template
set -eo pipefail
cd "$(dirname "$0")"

echo "[install] step: npm ci --omit=dev"
npm ci --omit=dev 2>&1

echo "[install] step: idempotent PostgreSQL initialization"
node init-db.js 2>&1

echo "[install] done"
